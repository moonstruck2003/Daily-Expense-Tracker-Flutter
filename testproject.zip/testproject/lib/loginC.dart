
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:testproject/reg.dart';
import 'package:testproject/regC.dart';



import 'package:testproject/reg.dart';

class LoginC extends GetxController{
  TextEditingController mail=TextEditingController();
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
  }

  void chkEmail() async {
    print(mail.text.toString());
    DatabaseReference ref = FirebaseDatabase.instance.ref("Mails/");

    await ref.set({
      "name": "John",
      "mail":mail.text.toString()

    });
    Get.to(()=>Reg());

  }


}

class Reg {
}
// var commentsRef = FirebaseDatabase.instance.ref("USERS/");
// await commentsRef.set({
//
// "id": 1,
// "name":"hgghgh"
//
//
// });