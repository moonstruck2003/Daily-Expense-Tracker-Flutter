
import 'package:firebase_database/firebase_database.dart';
import 'package:get/get.dart';

class RegC extends GetxController{
  var s="".obs;
  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    getData();
  }
  void getData() async {
    final ref = FirebaseDatabase.instance.ref();
    final snapshot = await ref.child('Mails/mail').get();
    if (snapshot.exists) {
      print(snapshot.value);
      s.value=snapshot.value.toString();
    } else {
      print('No data available.');
    }
  }


}