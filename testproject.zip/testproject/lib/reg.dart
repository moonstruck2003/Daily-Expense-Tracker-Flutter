import 'package:flutter/material.dart';
import 'package:get/get.dart';

import 'loginC.dart';

import 'regC.dart';


class Reg extends StatelessWidget{
  var c=Get.put(RegC());
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return  Scaffold(
        resizeToAvoidBottomInset: true,
        body: SafeArea(
          child: Container(
            color: Theme.of(context).cardColor,
            padding: EdgeInsets.all(10),
            child: Column(
              children: [
                Flexible(
                  flex: 3,
                  child: Center(
                      child: Padding(
                        padding: const EdgeInsets.all(10.0),
                        child: Text("Enter Otp".toUpperCase(),style: TextStyle(
                            fontSize: 30,
                            color: Theme.of(context).hintColor,
                            fontWeight: FontWeight.w900,
                            fontStyle: FontStyle.italic,
                            fontFamily: 'money'


                        ),),
                      )
                  ),
                ),
                Flexible(
                    flex: 8,
                    child: Container(
                      padding: EdgeInsets.all(20),
                      child: Column(
                        children: [

                          SizedBox(
                            //height: Get.find<OtpController>().height*0.05,
                          ),
                          Obx(() =>
                              Center(
                                  child: Text("hello "+Get.find<RegC>().s.value)

                              ),
                          ),

                          const SizedBox(height:  20),

                        ],
                      ),

                      decoration: BoxDecoration(
                        color: Theme.of(context).canvasColor,
                        borderRadius: BorderRadius.only(bottomLeft: Radius.circular(60),topRight: Radius.circular(60)), // Adjust the radius as needed
                      ),

                    )
                )


                // Visibility(
                //     //visible: otpEnterButtonPress,
                //     child:  Center(
                //       child: LoadingAnimationWidget.staggeredDotsWave(
                //         color: Theme.of(context).primaryColor,
                //         size: 50,
                //       ),
                //     )
                // )
              ],
            ),
          ),

        )
    )
    ;

  }



}
//https://firebase.flutter.dev/docs/firestore/usage/